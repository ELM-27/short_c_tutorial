#include <stdio.h>

int main(int argc, char * args[]) {
    printf("Hello, World! %d\n", argc);
    return 0;
}